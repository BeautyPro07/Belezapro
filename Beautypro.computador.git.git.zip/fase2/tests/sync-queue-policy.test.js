import { describe, it, expect } from 'vitest';
import {
  MAX_SYNC_ATTEMPTS,
  QUEUE_HARD_BLOCK,
  QUEUE_SOFT_WARN,
  buildQueueOperation,
  decideEnqueue,
  classifyFlushError,
  coalesceQueueByEntity,
  queueHasPendingDelete,
  queuePressure,
} from '../domain/pure/sync-queue-policy.mjs';

describe('shape da operação (política)', () => {
  it('buildQueueOperation define attempts 0, failed false, nextRetry 0', () => {
    const op = buildQueueOperation({
      tabela: 'clientes',
      operacao: 'upsert',
      payload: { id: 'c1', nome: 'Ana' },
    });
    expect(op.attempts).toBe(0);
    expect(op.failed).toBe(false);
    expect(op.nextRetry).toBe(0);
    expect(op.lastError).toBe(null);
    expect(op.tabela).toBe('clientes');
    expect(op.payload.id).toBe('c1');
  });
});

describe('enqueue — tombstone / delete / coalesce / hard block', () => {
  it('rejeita upsert se tombstone activo', () => {
    const r = decideEnqueue({
      tabela: 'clientes',
      operacao: 'upsert',
      payload: { id: 'c1' },
      queue: [],
      isTombstoned: true,
    });
    expect(r.action).toBe('reject');
    expect(r.reason).toBe('tombstone');
  });

  it('rejeita upsert se delete já está na fila', () => {
    const queue = [
      {
        tabela: 'clientes',
        operacao: 'delete',
        payload: { id: 'c1' },
      },
    ];
    expect(queueHasPendingDelete(queue, 'clientes', 'c1')).toBe(true);
    const r = decideEnqueue({
      tabela: 'clientes',
      operacao: 'upsert',
      payload: { id: 'c1' },
      queue,
      isTombstoned: false,
    });
    expect(r.action).toBe('reject');
    expect(r.reason).toBe('delete_already_queued');
  });

  it('coalesce remove ops anteriores do mesmo id', () => {
    const queue = [
      { tabela: 'clientes', operacao: 'upsert', payload: { id: 'c1', nome: 'A' } },
      { tabela: 'clientes', operacao: 'upsert', payload: { id: 'c2' } },
    ];
    const next = coalesceQueueByEntity(queue, 'clientes', 'c1');
    expect(next).toHaveLength(1);
    expect(next[0].payload.id).toBe('c2');
  });

  it('enqueue faz coalesce e acrescenta uma op', () => {
    const queue = [
      { tabela: 'clientes', operacao: 'upsert', payload: { id: 'c1', nome: 'Velho' } },
    ];
    const r = decideEnqueue({
      tabela: 'clientes',
      operacao: 'upsert',
      payload: { id: 'c1', nome: 'Novo' },
      queue,
      isTombstoned: false,
    });
    expect(r.action).toBe('enqueue');
    expect(r.nextQueue).toHaveLength(1);
    expect(r.nextQueue[0].payload.nome).toBe('Novo');
  });

  it('hard block quando fila já tem QUEUE_HARD_BLOCK itens', () => {
    const queue = Array.from({ length: QUEUE_HARD_BLOCK }, (_, i) => ({
      tabela: 'clientes',
      operacao: 'upsert',
      payload: { id: 'x' + i },
    }));
    const r = decideEnqueue({
      tabela: 'clientes',
      operacao: 'upsert',
      payload: { id: 'novo' },
      queue,
      isTombstoned: false,
    });
    expect(r.action).toBe('reject');
    expect(r.reason).toBe('hard_block');
  });

  it('pressão soft_warn em 1000', () => {
    expect(queuePressure(QUEUE_SOFT_WARN)).toBe('soft_warn');
    expect(queuePressure(0)).toBe('ok');
  });
});

describe('classifyFlushError — caminhos especiais (não “sempre 5 = DLQ”)', () => {
  it('SESSION_EXPIRED interrompe; não manda à DLQ; attempts não sobem neste ramo', () => {
    const r = classifyFlushError('SESSION_EXPIRED', 2);
    expect(r.outcome).toBe('session_expired_interrupt');
    expect(r.goesToDlq).toBe(false);
    expect(r.staysInQueue).toBe(true);
    expect(r.attemptsAfter).toBe(2);
  });

  it('LIMITE_PLANO_ATINGIDO → backoff na fila, não DLQ', () => {
    const r = classifyFlushError('LIMITE_PLANO_ATINGIDO', 4);
    expect(r.outcome).toBe('backoff_plan_limit');
    expect(r.goesToDlq).toBe(false);
    expect(r.staysInQueue).toBe(true);
    expect(r.attemptsAfter).toBe(5);
  });

  it('DUPLICADO → DLQ imediato', () => {
    const r = classifyFlushError('DUPLICADO_BLOQUEADO', 0);
    expect(r.outcome).toBe('dlq_duplicado');
    expect(r.goesToDlq).toBe(true);
  });

  it('erro genérico com attempts 4 → 5ª falha vai à DLQ', () => {
    const r = classifyFlushError('network', 4);
    expect(r.attemptsAfter).toBe(5);
    expect(r.attemptsAfter).toBe(MAX_SYNC_ATTEMPTS);
    expect(r.outcome).toBe('dlq_max_attempts');
    expect(r.goesToDlq).toBe(true);
  });

  it('erro genérico com attempts 0 → backoff_retry', () => {
    const r = classifyFlushError('timeout', 0);
    expect(r.outcome).toBe('backoff_retry');
    expect(r.goesToDlq).toBe(false);
    expect(r.staysInQueue).toBe(true);
  });
});
