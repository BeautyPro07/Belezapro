/**
 * BELEZAPRO — política mínima da Sync Queue (caracterização F2-03).
 * NÃO é uma segunda implementação completa de sync-queue.js.
 * Espelha apenas decisões de enqueue + classificação de erro de flush
 * conforme leitura do código de produção.
 */

export const MAX_SYNC_ATTEMPTS = 5;
export const QUEUE_SOFT_WARN = 1000;
export const QUEUE_HARD_BLOCK = 5000;
export const BATCH_SIZE = 25;

/**
 * Shape de uma op nova (campos iniciais observados em addToSyncQueue).
 * @param {{ tabela: string, operacao: string, payload: object, id?: string, ts?: number }} partial
 */
export function buildQueueOperation(partial) {
  return {
    id: partial.id || 'op-test-id',
    tabela: partial.tabela,
    operacao: partial.operacao,
    payload: partial.payload,
    ts: partial.ts != null ? partial.ts : 0,
    attempts: 0,
    failed: false,
    nextRetry: 0,
    lastError: null,
  };
}

/**
 * Há delete pendente na fila para o mesmo entidade?
 * @param {Array<{ tabela?: string, operacao?: string, payload?: { id?: string } }>} queue
 * @param {string} tabela
 * @param {string|number} entityId
 */
export function queueHasPendingDelete(queue, tabela, entityId) {
  if (entityId == null) return false;
  return (queue || []).some(
    (item) =>
      item &&
      item.tabela === tabela &&
      item.operacao === 'delete' &&
      item.payload &&
      item.payload.id === entityId,
  );
}

/**
 * Remove ops com o mesmo tabela + payload.id (coalesce antes de push).
 * @param {Array} queue
 * @param {string} tabela
 * @param {string|number} entityId
 */
export function coalesceQueueByEntity(queue, tabela, entityId) {
  if (entityId == null) return (queue || []).slice();
  return (queue || []).filter(
    (item) =>
      !(item && item.tabela === tabela && item.payload && item.payload.id === entityId),
  );
}

/**
 * Decisão de enqueue — espelha a ordem de guards de addToSyncQueue (sem side-effects).
 *
 * @param {object} args
 * @param {string} args.tabela
 * @param {string} args.operacao
 * @param {{ id?: string }|null} args.payload
 * @param {Array} args.queue
 * @param {boolean} args.isTombstoned - isDeletedItem(id, tabela)
 * @returns {{ action: 'enqueue'|'reject', reason?: string, nextQueue?: Array, operation?: object }}
 */
export function decideEnqueue(args) {
  const { tabela, operacao, payload, queue, isTombstoned } = args;
  const entityId = payload && payload.id;
  let q = (queue || []).slice();

  if (operacao !== 'delete' && entityId != null && isTombstoned) {
    return { action: 'reject', reason: 'tombstone' };
  }

  if (entityId != null) {
    if (queueHasPendingDelete(q, tabela, entityId) && operacao !== 'delete') {
      return { action: 'reject', reason: 'delete_already_queued' };
    }
    q = coalesceQueueByEntity(q, tabela, entityId);
  }

  if (q.length >= QUEUE_HARD_BLOCK) {
    return { action: 'reject', reason: 'hard_block' };
  }

  const operation = buildQueueOperation({
    tabela,
    operacao,
    payload: payload || {},
  });
  q.push(operation);
  return { action: 'enqueue', nextQueue: q, operation };
}

/**
 * Classifica o próximo passo após erro no flush (catch), sem mutar a op.
 * Preserva caminhos especiais observados no código.
 *
 * @param {string} errorMessage
 * @param {number} currentAttempts - attempts ANTES do incremento deste erro
 * @returns {{ outcome: string, attemptsAfter: number, goesToDlq: boolean, staysInQueue: boolean }}
 */
export function classifyFlushError(errorMessage, currentAttempts) {
  const msg = String(errorMessage || '');
  const attemptsAfter = (currentAttempts || 0) + 1;

  if (msg === 'SESSION_EXPIRED') {
    return {
      outcome: 'session_expired_interrupt',
      attemptsAfter: currentAttempts || 0, // código NÃO incrementa attempts neste ramo antes do break
      goesToDlq: false,
      staysInQueue: true,
      note: 'attempts not incremented in SESSION_EXPIRED branch before interrupt',
    };
  }

  if (msg === 'LIMITE_PLANO_ATINGIDO') {
    return {
      outcome: 'backoff_plan_limit',
      attemptsAfter,
      goesToDlq: false,
      staysInQueue: true,
    };
  }

  if (msg === 'DUPLICADO_BLOQUEADO' || msg.indexOf('DUPLICADO') >= 0) {
    return {
      outcome: 'dlq_duplicado',
      attemptsAfter: currentAttempts || 0, // moveOpToDlq sem exigir attempts++ no mesmo sítio
      goesToDlq: true,
      staysInQueue: false,
      note: 'immediate DLQ; attempts++ not applied in this branch before moveOpToDlq',
    };
  }

  // ramo genérico: attempts++ já reflectido em attemptsAfter
  if (attemptsAfter >= MAX_SYNC_ATTEMPTS) {
    return {
      outcome: 'dlq_max_attempts',
      attemptsAfter,
      goesToDlq: true,
      staysInQueue: false,
    };
  }

  return {
    outcome: 'backoff_retry',
    attemptsAfter,
    goesToDlq: false,
    staysInQueue: true,
  };
}

/**
 * Pressão da fila (só limiares).
 * @param {number} length
 */
export function queuePressure(length) {
  if (length >= QUEUE_HARD_BLOCK) return 'hard_block';
  if (length >= QUEUE_SOFT_WARN) return 'soft_warn';
  return 'ok';
}
