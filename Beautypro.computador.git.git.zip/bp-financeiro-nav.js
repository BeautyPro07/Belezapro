/**
 * bp-financeiro-nav.js — back neutro + reabrir menu
 * Visual da seta: CSS (.bp-fin-back). Bundle intacto.
 */
(function () {
  'use strict';
  var IDS = ['modal-bp-fluxo', 'modal-bp-rentab', 'modal-bp-meta', 'modal-despesa'];
  var ARROW =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<path d="M15 18l-6-6 6-6"/></svg>';

  function closeFin(id) {
    if (typeof closeModal === 'function') {
      try { closeModal(id); return; } catch (e) {}
    }
    var el = document.getElementById(id);
    if (el) el.classList.remove('open');
  }

  function openMenu() {
    var dd = document.getElementById('menu-dropdown');
    var btn = document.getElementById('menu-btn');
    if (!dd) return;
    dd.style.display = 'block';
    if (btn) btn.setAttribute('aria-expanded', 'true');
    var toggles = dd.querySelectorAll('.bp-acc-toggle');
    for (var i = 0; i < toggles.length; i++) {
      var t = toggles[i];
      if ((t.textContent || '').indexOf('Financeiro') !== -1) {
        t.setAttribute('aria-expanded', 'true');
        var panel = t.parentElement && t.parentElement.querySelector('.bp-acc-panel');
        if (panel) panel.classList.add('open');
        break;
      }
    }
  }

  function ensureBack(modal) {
    if (!modal || modal.querySelector('.bp-fin-back')) return;
    var host = modal.querySelector('.bp-sheet-header');
    if (!host) host = modal.querySelector('.modal-sheet');
    if (!host) return;
    var pos = window.getComputedStyle(host).position;
    if (pos === 'static') host.style.position = 'relative';

    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'bp-fin-back';
    b.setAttribute('aria-label', 'Voltar ao menu');
    b.innerHTML = ARROW;
    b.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      closeFin(modal.id);
      setTimeout(openMenu, 40);
    });
    host.insertBefore(b, host.firstChild);
  }

  function scan() {
    for (var i = 0; i < IDS.length; i++) {
      var el = document.getElementById(IDS[i]);
      if (el && el.classList.contains('open')) ensureBack(el);
    }
  }

  function boot() {
    scan();
    if (typeof MutationObserver !== 'undefined') {
      new MutationObserver(scan).observe(document.body, {
        subtree: true,
        attributes: true,
        attributeFilter: ['class']
      });
    }
    setInterval(scan, 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
